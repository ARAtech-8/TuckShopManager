# Tuck Shop Manager (Android)

Simple stock, sales, profit and cash-flow app for a small shop. Kotlin + Jetpack Compose + Room. Works offline; all data stays on the phone.

## Get the APK (same way as your other apps)
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab -> **Build APK** -> it runs automatically on push (or press *Run workflow*).
3. When it turns green, open the run and download **TuckShopManager-debug-apk**. Unzip, copy `app-debug.apk` to the phone, install (allow "unknown sources").

If the build fails, open the failed step, copy the error text and send it to me; it will be a quick fix.

## What the owner does
1. **More > Settings**: shop name, currency symbol, money in the shop at the start.
2. **Stock**: add products one by one, or **Import Excel** (.xlsx or .csv). Use *Get an Excel template* for the layout. Columns: Product Name, Category, Unit, Cost Price, Selling Price, Quantity In Stock, Reorder Level.
3. **Sell**: tap items, review, choose Cash / Mobile money / On credit, Sale done.
4. Record **expenses**, **stock bought** (Stock > tap item > "I bought more"), and money put in/taken out.
5. **Reports**: pick Today / This week / This month / 3 months / 6 months / 12 months. Insights tab for analytics; Statements tab for downloadable PDF and Excel (CSV).

## Statements produced (PDF, shareable, or Excel/CSV)
Profit and Loss, Cash Flow, What the shop has and owes (balance sheet), Sales by Product, Sales Over Time, Stock Value, Who Owes Who. One-tap "everything in one PDF".

## How the numbers work
- Cost of each sale is the average buying price at the moment of the sale, so profit stays correct when supplier prices change.
- Profit and Loss counts a credit sale as sales. Cash Flow only counts money that actually moved.
- Damaged/expired/missing stock is shown as a loss in the Profit and Loss.
- Cancelling a sale puts the stock back and removes it from every report.
- Weeks run Monday to Sunday. "3/6/12 months" count back from today.

## Free trial and keys
- The app works fully for 24 hours after installation. After that it shows a lock screen: "WhatsApp +263 715 048 687 to get key".
- The lock screen shows the phone's **Device ID** (e.g. K7M2-9QXA) with Copy and Open WhatsApp buttons.
- Generate the key with `keygen.html` (kept OUTSIDE this project, never upload it to GitHub). Paste the Device ID, tap Generate, send the key.
- A key only works on the phone whose Device ID it was made for. Once entered, that phone stays unlocked permanently.
- Changing the phone date backwards does not extend the trial.
- The app is signed with the fixed key in `app/debug.keystore`, so new builds install over old ones without losing data or the licence. Do not delete that file.
- To change the secret: replace the 32-character secret in BOTH `domain/License.kt` and `keygen.html`. Old keys stop working.

## Build in a GitHub Codespace
1. Put this project in a GitHub repo, open it in a Codespace (Code > Codespaces > Create).
2. In the terminal run:  `bash build_codespace.sh`  (first run takes about 5-10 minutes).
3. When it says DONE, in the file explorer right-click `app/build/outputs/apk/debug/app-debug.apk` > Download.
