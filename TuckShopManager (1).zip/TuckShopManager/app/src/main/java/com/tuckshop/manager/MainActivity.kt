package com.tuckshop.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.tuckshop.manager.ui.LicenseGate
import com.tuckshop.manager.ui.ShopApp
import com.tuckshop.manager.ui.TuckShopTheme

class MainActivity : ComponentActivity() {
    private val vm: ShopViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TuckShopTheme {
                LicenseGate((application as TuckShopApp).licenses) {
                    ShopApp(vm)
                }
            }
        }
    }
}
