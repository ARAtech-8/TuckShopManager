package com.tuckshop.manager

import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tuckshop.manager.data.CartLine
import com.tuckshop.manager.data.Customer
import com.tuckshop.manager.data.Product
import com.tuckshop.manager.data.ShopRepository
import com.tuckshop.manager.domain.Fmt
import com.tuckshop.manager.domain.ShopSettings
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ShopViewModel(app: Application) : AndroidViewModel(app) {
    val repo: ShopRepository = (app as TuckShopApp).repo

    val products: StateFlow<List<Product>> =
        repo.products.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val customers: StateFlow<List<Customer>> =
        repo.customers.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val settings: StateFlow<ShopSettings> get() = repo.settings.state

    /** The sale being built on the Sell screen. Kept here so it survives switching tabs. */
    val cart = mutableStateListOf<CartLine>()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> get() = _messages

    fun say(text: String) {
        _messages.tryEmit(text)
    }

    /** Run something in the background, optionally telling the user when it is done. */
    fun go(done: String? = null, block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
                if (done != null) say(done)
            } catch (e: Exception) {
                say("Something went wrong: " + (e.message ?: "unknown error"))
            }
        }
    }

    // ------------------------------------------------------------------ cart
    val cartTotal: Double get() = cart.sumOf { it.qty * it.price }

    fun addToCart(p: Product) {
        val i = cart.indexOfFirst { it.product.id == p.id }
        val newQty = if (i >= 0) cart[i].qty + 1.0 else 1.0
        if (i >= 0) cart[i] = cart[i].copy(qty = newQty) else cart.add(CartLine(p, 1.0, p.sellPrice))
        if (newQty > p.stockQty) say("Only " + Fmt.qty(maxOf(0.0, p.stockQty)) + " of " + p.name + " in stock. Check your stock count.")
    }

    fun setQty(index: Int, qty: Double) {
        if (index !in cart.indices) return
        if (qty <= 0.0) cart.removeAt(index) else cart[index] = cart[index].copy(qty = qty)
    }

    fun setPrice(index: Int, price: Double) {
        if (index !in cart.indices || price < 0.0) return
        cart[index] = cart[index].copy(price = price)
    }

    fun checkout(method: String, customerId: Long?, note: String, onDone: () -> Unit) {
        val lines = cart.toList()
        if (lines.isEmpty()) return
        val total = lines.sumOf { it.qty * it.price }
        go {
            repo.checkout(lines, method, customerId, note)
            cart.clear()
            say("Sale saved: " + settings.value.symbol + Fmt.money(total))
            onDone()
        }
    }
}
