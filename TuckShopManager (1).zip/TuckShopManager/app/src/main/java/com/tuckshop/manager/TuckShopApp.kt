package com.tuckshop.manager

import android.app.Application
import com.tuckshop.manager.data.LicenseStore
import com.tuckshop.manager.data.SettingsStore
import com.tuckshop.manager.data.ShopDatabase
import com.tuckshop.manager.data.ShopRepository

class TuckShopApp : Application() {
    lateinit var repo: ShopRepository
        private set

    lateinit var licenses: LicenseStore
        private set

    override fun onCreate() {
        super.onCreate()
        licenses = LicenseStore(this)
        repo = ShopRepository(ShopDatabase.build(this), SettingsStore(this))
    }
}
