package com.tuckshop.manager.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Payment methods stored on a sale. */
object Method {
    const val CASH = "CASH"
    const val MOBILE = "MOBILE"
    const val CREDIT = "CREDIT"

    fun label(m: String): String = when (m) {
        CASH -> "Cash"
        MOBILE -> "Mobile money"
        CREDIT -> "On credit"
        else -> m
    }
}

@Entity(tableName = "products", indices = [Index("name")])
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String = "General",
    val unit: String = "each",
    val costPrice: Double = 0.0,
    val sellPrice: Double = 0.0,
    val stockQty: Double = 0.0,
    val reorderLevel: Double = 5.0,
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = ""
)

@Entity(tableName = "sales", indices = [Index("time")])
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val time: Long = System.currentTimeMillis(),
    val total: Double,
    val method: String,
    val customerId: Long? = null,
    val note: String = "",
    val voided: Boolean = false
)

@Entity(tableName = "sale_items", indices = [Index("saleId"), Index("productId")])
data class SaleItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val productId: Long,
    val name: String,
    val qty: Double,
    val unitPrice: Double,
    val unitCost: Double
)

/** Stock bought from a supplier. paidNow is the part paid immediately; the rest is owed. */
@Entity(tableName = "restocks", indices = [Index("time")])
data class Restock(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val time: Long = System.currentTimeMillis(),
    val productId: Long,
    val productName: String,
    val qty: Double,
    val unitCost: Double,
    val supplier: String = "",
    val paidNow: Double
)

@Entity(tableName = "supplier_payments", indices = [Index("time")])
data class SupplierPayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val time: Long = System.currentTimeMillis(),
    val supplier: String,
    val amount: Double,
    val note: String = ""
)

/** Stock removed (damaged, expired, missing, own use) or corrected. qtyChange is negative for a loss. */
@Entity(tableName = "adjustments", indices = [Index("time")])
data class Adjustment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val time: Long = System.currentTimeMillis(),
    val productId: Long,
    val productName: String,
    val qtyChange: Double,
    val unitCost: Double,
    val reason: String
)

@Entity(tableName = "expenses", indices = [Index("time")])
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val time: Long = System.currentTimeMillis(),
    val category: String,
    val amount: Double,
    val note: String = ""
)

/** Money the owner put into the shop (positive) or took out (negative). */
@Entity(tableName = "owner_txns", indices = [Index("time")])
data class OwnerTxn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val time: Long = System.currentTimeMillis(),
    val amount: Double,
    val note: String = ""
)

@Entity(tableName = "customer_payments", indices = [Index("time"), Index("customerId")])
data class CustomerPayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val time: Long = System.currentTimeMillis(),
    val amount: Double,
    val note: String = ""
)

/** One sold line joined with its sale's time and payment method (query result, not a table). */
data class SaleLine(
    val saleId: Long,
    val productId: Long,
    val name: String,
    val qty: Double,
    val unitPrice: Double,
    val unitCost: Double,
    val saleTime: Long,
    val method: String
)

/** A name with an amount (query result, not a table). */
data class NameAmount(
    val name: String,
    val amount: Double
)
