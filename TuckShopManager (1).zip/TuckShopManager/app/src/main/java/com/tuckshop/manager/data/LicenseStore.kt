package com.tuckshop.manager.data

import android.content.Context
import android.provider.Settings
import com.tuckshop.manager.domain.License
import kotlin.math.max

data class LicenseState(val activated: Boolean, val trialMsLeft: Long) {
    val locked: Boolean get() = !activated && trialMsLeft <= 0
}

class LicenseStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("license", Context.MODE_PRIVATE)

    val deviceCode: String by lazy {
        val id = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        License.deviceCode(id, context.packageName)
    }

    fun state(now: Long = System.currentTimeMillis()): LicenseState {
        val key = prefs.getString("key", null)
        if (key != null && License.isValid(deviceCode, key)) return LicenseState(true, 0L)

        // Never let the clock go backwards: setting the phone date back does not extend the trial.
        val effectiveNow = max(now, prefs.getLong("last_seen", 0L))
        prefs.edit().putLong("last_seen", effectiveNow).apply()

        val installed = try {
            context.packageManager.getPackageInfo(context.packageName, 0).firstInstallTime
        } catch (e: Exception) {
            effectiveNow
        }
        return LicenseState(false, installed + License.TRIAL_MS - effectiveNow)
    }

    /** Returns true if the key is right for this phone, and remembers it. */
    fun activate(input: String): Boolean {
        if (!License.isValid(deviceCode, input)) return false
        prefs.edit().putString("key", License.normalize(input)).apply()
        return true
    }
}
