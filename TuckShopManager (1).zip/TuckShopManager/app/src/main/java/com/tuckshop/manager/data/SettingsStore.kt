package com.tuckshop.manager.data

import android.content.Context
import com.tuckshop.manager.domain.ShopSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("shop_settings", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(load())
    val state: StateFlow<ShopSettings> get() = _state

    private fun load(): ShopSettings = ShopSettings(
        shopName = prefs.getString("name", "My Tuck Shop") ?: "My Tuck Shop",
        symbol = prefs.getString("symbol", "$") ?: "$",
        openingMoney = prefs.getString("opening", "0")?.toDoubleOrNull() ?: 0.0
    )

    fun save(s: ShopSettings) {
        prefs.edit()
            .putString("name", s.shopName)
            .putString("symbol", s.symbol)
            .putString("opening", s.openingMoney.toString())
            .apply()
        _state.value = s
    }
}
