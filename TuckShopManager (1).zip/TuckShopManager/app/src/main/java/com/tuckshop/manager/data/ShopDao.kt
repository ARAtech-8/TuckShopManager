package com.tuckshop.manager.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ShopDao {

    // ---------- products ----------
    @Query("SELECT * FROM products WHERE active = 1 ORDER BY name COLLATE NOCASE")
    fun productsFlow(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE active = 1")
    suspend fun productsNow(): List<Product>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun product(id: Long): Product?

    @Query("SELECT * FROM products WHERE active = 1 AND LOWER(name) = LOWER(:name) LIMIT 1")
    suspend fun productByName(name: String): Product?

    @Insert
    suspend fun insertProduct(p: Product): Long

    @Update
    suspend fun updateProduct(p: Product)

    @Query("UPDATE products SET active = 0 WHERE id = :id")
    suspend fun archiveProduct(id: Long)

    // ---------- customers ----------
    @Query("SELECT * FROM customers ORDER BY name COLLATE NOCASE")
    fun customersFlow(): Flow<List<Customer>>

    @Query("SELECT * FROM customers")
    suspend fun customersNow(): List<Customer>

    @Insert
    suspend fun insertCustomer(c: Customer): Long

    // ---------- sales ----------
    @Insert
    suspend fun insertSale(s: Sale): Long

    @Insert
    suspend fun insertSaleItem(i: SaleItem): Long

    @Query("SELECT * FROM sales WHERE id = :id")
    suspend fun sale(id: Long): Sale?

    @Query("SELECT * FROM sale_items WHERE saleId = :saleId")
    suspend fun saleItems(saleId: Long): List<SaleItem>

    @Query("UPDATE sales SET voided = 1 WHERE id = :id")
    suspend fun markVoided(id: Long)

    @Query("SELECT * FROM sales ORDER BY time DESC LIMIT :limit")
    fun recentSalesFlow(limit: Int): Flow<List<Sale>>

    @Query(
        "SELECT si.saleId AS saleId, si.productId AS productId, si.name AS name, si.qty AS qty, " +
            "si.unitPrice AS unitPrice, si.unitCost AS unitCost, s.time AS saleTime, s.method AS method " +
            "FROM sale_items si INNER JOIN sales s ON s.id = si.saleId " +
            "WHERE s.voided = 0 AND s.time >= :from AND s.time < :to"
    )
    suspend fun saleLines(from: Long, to: Long): List<SaleLine>

    @Query(
        "SELECT method AS name, COALESCE(SUM(total), 0) AS amount FROM sales " +
            "WHERE voided = 0 AND time >= :from AND time < :to GROUP BY method"
    )
    suspend fun salesByMethod(from: Long, to: Long): List<NameAmount>

    @Query("SELECT * FROM sales WHERE voided = 0 AND method = 'CREDIT'")
    suspend fun allCreditSales(): List<Sale>

    // ---------- stock buying ----------
    @Insert
    suspend fun insertRestock(r: Restock): Long

    @Query("SELECT * FROM restocks")
    suspend fun allRestocks(): List<Restock>

    @Query("SELECT COALESCE(SUM(paidNow), 0) FROM restocks WHERE time >= :from AND time < :to")
    suspend fun sumRestockPaid(from: Long, to: Long): Double

    @Query("SELECT COALESCE(SUM(qty * unitCost), 0) FROM restocks WHERE time >= :from AND time < :to")
    suspend fun sumRestockTotal(from: Long, to: Long): Double

    @Insert
    suspend fun insertSupplierPayment(p: SupplierPayment): Long

    @Query("SELECT * FROM supplier_payments")
    suspend fun allSupplierPayments(): List<SupplierPayment>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM supplier_payments WHERE time >= :from AND time < :to")
    suspend fun sumSupplierPayments(from: Long, to: Long): Double

    // ---------- adjustments ----------
    @Insert
    suspend fun insertAdjustment(a: Adjustment): Long

    @Query(
        "SELECT reason AS name, COALESCE(SUM(-qtyChange * unitCost), 0) AS amount FROM adjustments " +
            "WHERE time >= :from AND time < :to GROUP BY reason"
    )
    suspend fun adjustmentLossByReason(from: Long, to: Long): List<NameAmount>

    // ---------- expenses ----------
    @Insert
    suspend fun insertExpense(e: Expense): Long

    @Delete
    suspend fun deleteExpense(e: Expense)

    @Query("SELECT * FROM expenses ORDER BY time DESC LIMIT 300")
    fun expensesFlow(): Flow<List<Expense>>

    @Query(
        "SELECT category AS name, COALESCE(SUM(amount), 0) AS amount FROM expenses " +
            "WHERE time >= :from AND time < :to GROUP BY category ORDER BY amount DESC"
    )
    suspend fun expensesByCategory(from: Long, to: Long): List<NameAmount>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE time >= :from AND time < :to")
    suspend fun sumExpenses(from: Long, to: Long): Double

    // ---------- owner money ----------
    @Insert
    suspend fun insertOwnerTxn(t: OwnerTxn): Long

    @Delete
    suspend fun deleteOwnerTxn(t: OwnerTxn)

    @Query("SELECT * FROM owner_txns ORDER BY time DESC LIMIT 300")
    fun ownerTxnsFlow(): Flow<List<OwnerTxn>>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM owner_txns WHERE amount > 0 AND time >= :from AND time < :to")
    suspend fun sumOwnerIn(from: Long, to: Long): Double

    @Query("SELECT COALESCE(-SUM(amount), 0) FROM owner_txns WHERE amount < 0 AND time >= :from AND time < :to")
    suspend fun sumOwnerOut(from: Long, to: Long): Double

    // ---------- customer payments ----------
    @Insert
    suspend fun insertCustomerPayment(p: CustomerPayment): Long

    @Query("SELECT * FROM customer_payments")
    suspend fun allCustomerPayments(): List<CustomerPayment>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM customer_payments WHERE time >= :from AND time < :to")
    suspend fun sumCustomerPayments(from: Long, to: Long): Double
}
