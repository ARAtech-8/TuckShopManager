package com.tuckshop.manager.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        Product::class, Customer::class, Sale::class, SaleItem::class, Restock::class,
        SupplierPayment::class, Adjustment::class, Expense::class, OwnerTxn::class,
        CustomerPayment::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ShopDatabase : RoomDatabase() {
    abstract fun dao(): ShopDao

    companion object {
        const val NAME = "tuckshop.db"

        fun build(context: Context): ShopDatabase =
            Room.databaseBuilder(context.applicationContext, ShopDatabase::class.java, NAME)
                // TRUNCATE keeps everything in one file, which makes backup/restore a simple file copy.
                .setJournalMode(JournalMode.TRUNCATE)
                .build()
    }
}
