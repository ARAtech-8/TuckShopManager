package com.tuckshop.manager.data

import androidx.room.withTransaction
import com.tuckshop.manager.domain.Engine
import com.tuckshop.manager.domain.Period
import com.tuckshop.manager.domain.Position
import com.tuckshop.manager.domain.RawData
import com.tuckshop.manager.domain.ReportBundle
import com.tuckshop.manager.domain.TimeRange
import com.tuckshop.manager.domain.previousRange
import com.tuckshop.manager.domain.range
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import kotlin.math.max

/** One line in the shopping cart on the Sell screen. */
data class CartLine(val product: Product, val qty: Double, val price: Double)

/** One row of a product sheet read from Excel/CSV. Null means "the sheet had no value". */
data class ImportRow(
    val name: String,
    val category: String,
    val unit: String,
    val cost: Double?,
    val sell: Double?,
    val qty: Double?,
    val reorder: Double?
)

data class CustomerBalance(val customer: Customer, val owed: Double)

class ShopRepository(val db: ShopDatabase, val settings: SettingsStore) {
    private val dao = db.dao()

    /** Goes up by one after every change, so screens know to reload their reports. */
    val version = MutableStateFlow(0)
    private fun bump() {
        version.value = version.value + 1
    }

    val products: Flow<List<Product>> = dao.productsFlow()
    val customers: Flow<List<Customer>> = dao.customersFlow()
    val expenses: Flow<List<Expense>> = dao.expensesFlow()
    val ownerTxns: Flow<List<OwnerTxn>> = dao.ownerTxnsFlow()
    fun recentSales(limit: Int): Flow<List<Sale>> = dao.recentSalesFlow(limit)

    // ---------------------------------------------------------------- products
    suspend fun saveProduct(p: Product): Long {
        val id = if (p.id == 0L) dao.insertProduct(p) else {
            dao.updateProduct(p)
            p.id
        }
        bump()
        return id
    }

    suspend fun archiveProduct(id: Long) {
        dao.archiveProduct(id)
        bump()
    }

    suspend fun productNameTaken(name: String, exceptId: Long): Boolean {
        val p = dao.productByName(name.trim()) ?: return false
        return p.id != exceptId
    }

    suspend fun importRows(rows: List<ImportRow>): Pair<Int, Int> {
        val result = db.withTransaction {
            var added = 0
            var updated = 0
            for (r in rows) {
                val ex = dao.productByName(r.name)
                if (ex == null) {
                    dao.insertProduct(
                        Product(
                            name = r.name,
                            category = r.category.ifBlank { "General" },
                            unit = r.unit.ifBlank { "each" },
                            costPrice = r.cost ?: 0.0,
                            sellPrice = r.sell ?: 0.0,
                            stockQty = r.qty ?: 0.0,
                            reorderLevel = r.reorder ?: 5.0
                        )
                    )
                    added++
                } else {
                    dao.updateProduct(
                        ex.copy(
                            category = r.category.ifBlank { ex.category },
                            unit = r.unit.ifBlank { ex.unit },
                            costPrice = r.cost ?: ex.costPrice,
                            sellPrice = r.sell ?: ex.sellPrice,
                            stockQty = r.qty ?: ex.stockQty,
                            reorderLevel = r.reorder ?: ex.reorderLevel
                        )
                    )
                    updated++
                }
            }
            Pair(added, updated)
        }
        bump()
        return result
    }

    // ---------------------------------------------------------------- selling
    suspend fun checkout(lines: List<CartLine>, method: String, customerId: Long?, note: String): Long {
        val id = db.withTransaction {
            val total = lines.sumOf { it.qty * it.price }
            val saleId = dao.insertSale(Sale(total = total, method = method, customerId = customerId, note = note))
            for (l in lines) {
                val p = dao.product(l.product.id) ?: continue
                dao.insertSaleItem(
                    SaleItem(
                        saleId = saleId, productId = p.id, name = p.name,
                        qty = l.qty, unitPrice = l.price, unitCost = p.costPrice
                    )
                )
                dao.updateProduct(p.copy(stockQty = p.stockQty - l.qty))
            }
            saleId
        }
        bump()
        return id
    }

    suspend fun saleItems(saleId: Long): List<SaleItem> = dao.saleItems(saleId)

    suspend fun customerName(id: Long?): String? =
        if (id == null) null else dao.customersNow().firstOrNull { it.id == id }?.name

    /** Cancel a sale that was entered by mistake: puts the stock back and removes it from all reports. */
    suspend fun voidSale(id: Long) {
        db.withTransaction {
            val s = dao.sale(id)
            if (s != null && !s.voided) {
                dao.markVoided(id)
                for (it in dao.saleItems(id)) {
                    val p = dao.product(it.productId)
                    if (p != null) dao.updateProduct(p.copy(stockQty = p.stockQty + it.qty))
                }
            }
        }
        bump()
    }

    // ---------------------------------------------------------------- stock
    /** Stock bought. The buying price is averaged with what is already on the shelf. */
    suspend fun restock(productId: Long, qty: Double, unitCost: Double, supplier: String, paidNow: Double) {
        db.withTransaction {
            val cur = dao.product(productId)
            if (cur != null) {
                val oldQty = max(0.0, cur.stockQty)
                val newCost = if (oldQty + qty > 0.0) (oldQty * cur.costPrice + qty * unitCost) / (oldQty + qty) else unitCost
                dao.insertRestock(
                    Restock(
                        productId = cur.id, productName = cur.name, qty = qty, unitCost = unitCost,
                        supplier = supplier.trim(), paidNow = paidNow
                    )
                )
                dao.updateProduct(cur.copy(stockQty = cur.stockQty + qty, costPrice = newCost))
            }
        }
        bump()
    }

    /** qtyChange is negative when stock is lost, positive when more is found during a count. */
    suspend fun adjust(productId: Long, qtyChange: Double, reason: String) {
        db.withTransaction {
            val cur = dao.product(productId)
            if (cur != null) {
                dao.insertAdjustment(
                    Adjustment(
                        productId = cur.id, productName = cur.name, qtyChange = qtyChange,
                        unitCost = cur.costPrice, reason = reason
                    )
                )
                dao.updateProduct(cur.copy(stockQty = cur.stockQty + qtyChange))
            }
        }
        bump()
    }

    // ---------------------------------------------------------------- money in/out
    suspend fun addExpense(category: String, amount: Double, note: String) {
        dao.insertExpense(Expense(category = category, amount = amount, note = note))
        bump()
    }

    suspend fun deleteExpense(e: Expense) {
        dao.deleteExpense(e)
        bump()
    }

    suspend fun addOwnerTxn(amount: Double, note: String) {
        dao.insertOwnerTxn(OwnerTxn(amount = amount, note = note))
        bump()
    }

    suspend fun deleteOwnerTxn(t: OwnerTxn) {
        dao.deleteOwnerTxn(t)
        bump()
    }

    suspend fun addCustomer(name: String, phone: String): Long {
        val id = dao.insertCustomer(Customer(name = name.trim(), phone = phone.trim()))
        bump()
        return id
    }

    suspend fun receivePayment(customerId: Long, amount: Double) {
        dao.insertCustomerPayment(CustomerPayment(customerId = customerId, amount = amount))
        bump()
    }

    suspend fun paySupplier(supplier: String, amount: Double) {
        dao.insertSupplierPayment(SupplierPayment(supplier = supplier, amount = amount))
        bump()
    }

    suspend fun customerBalances(): List<CustomerBalance> {
        val all = dao.customersNow()
        val sales = dao.allCreditSales()
        val pays = dao.allCustomerPayments()
        return all.map { c ->
            CustomerBalance(
                c,
                sales.filter { it.customerId == c.id }.sumOf { it.total } - pays.filter { it.customerId == c.id }.sumOf { it.amount }
            )
        }.sortedByDescending { it.owed }
    }

    suspend fun supplierBalances(): List<NameAmount> =
        Engine.creditors(dao.allRestocks(), dao.allSupplierPayments())

    // ---------------------------------------------------------------- reports
    private suspend fun netBetween(from: Long, to: Long): Double {
        val received = dao.salesByMethod(from, to).filter { it.name != Method.CREDIT }.sumOf { it.amount }
        return Engine.netMoney(
            received, dao.sumCustomerPayments(from, to), dao.sumRestockPaid(from, to),
            dao.sumSupplierPayments(from, to), dao.sumExpenses(from, to),
            dao.sumOwnerIn(from, to), dao.sumOwnerOut(from, to)
        )
    }

    private suspend fun rawData(range: TimeRange): RawData {
        val opening = settings.state.value.openingMoney + netBetween(0L, range.start)
        return RawData(
            range = range,
            lines = dao.saleLines(range.start, range.end),
            salesByMethod = dao.salesByMethod(range.start, range.end),
            expenses = dao.expensesByCategory(range.start, range.end),
            losses = dao.adjustmentLossByReason(range.start, range.end).filter { kotlin.math.abs(it.amount) > 0.0001 },
            restockPaid = dao.sumRestockPaid(range.start, range.end),
            restockTotal = dao.sumRestockTotal(range.start, range.end),
            supplierPaid = dao.sumSupplierPayments(range.start, range.end),
            customerPaid = dao.sumCustomerPayments(range.start, range.end),
            ownerIn = dao.sumOwnerIn(range.start, range.end),
            ownerOut = dao.sumOwnerOut(range.start, range.end),
            openingMoney = opening
        )
    }

    suspend fun bundle(period: Period): ReportBundle = withContext(Dispatchers.Default) {
        val now = System.currentTimeMillis()
        val range = period.range(now)
        val raw = rawData(range)
        val prevRange = period.previousRange(now)
        val prevLines = dao.saleLines(prevRange.start, prevRange.end)
        val products = dao.productsNow()
        val last30 = dao.saleLines(now - 30L * 24 * 3600 * 1000, now + 1)
        val stats = Engine.productStats(raw.lines)
        val kind = Engine.bucketKind(period)
        val position = Position(
            money = settings.state.value.openingMoney + netBetween(0L, now + 1),
            stockValue = Engine.stockValue(products),
            debtors = Engine.debtors(dao.allCreditSales(), dao.allCustomerPayments(), dao.customersNow()),
            creditors = Engine.creditors(dao.allRestocks(), dao.allSupplierPayments())
        )
        ReportBundle(
            period = period,
            range = range,
            raw = raw,
            summary = Engine.summary(raw.lines),
            prev = Engine.summary(prevLines),
            stats = stats,
            trend = Engine.trend(raw.lines, range, kind),
            trendKind = kind,
            products = products,
            notSelling = Engine.notSelling(products, stats),
            reorder = Engine.reorder(products, last30),
            position = position,
            busiestHour = Engine.busiestHour(raw.lines),
            bestWeekday = Engine.bestWeekday(raw.lines)
        )
    }
}
