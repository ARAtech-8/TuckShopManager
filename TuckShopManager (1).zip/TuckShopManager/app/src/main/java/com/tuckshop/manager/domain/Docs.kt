package com.tuckshop.manager.domain

import com.tuckshop.manager.data.Method

enum class RowStyle { HEADER, SECTION, NORMAL, SUBTOTAL, TOTAL, NOTE }

data class DocRow(val cells: List<String>, val style: RowStyle = RowStyle.NORMAL)

/** A printable statement: used for the on-screen view, the PDF and the CSV/Excel export. */
data class Doc(
    val key: String,
    val title: String,
    val blurb: String,
    val rows: List<DocRow>,
    val weights: List<Float>
)

/** Builds all statements in plain language for one reporting period. */
class DocBuilder(private val shop: ShopSettings, private val b: ReportBundle) {

    private val m: (Double) -> String = { Fmt.money(it) }

    private fun two(label: String, v: Double, style: RowStyle = RowStyle.NORMAL) =
        DocRow(listOf(label, m(v)), style)

    private fun section(label: String) = DocRow(listOf(label, ""), RowStyle.SECTION)
    private fun note(text: String) = DocRow(listOf(text, ""), RowStyle.NOTE)

    fun all(): List<Doc> = listOf(
        profitAndLoss(), cashFlow(), position(), salesByProduct(), salesOverTime(), stockValuation(), debts()
    )

    // ------------------------------------------------------------------------------------------
    fun profitAndLoss(): Doc {
        val r = b.raw
        val s = b.summary
        val gross = s.sales - s.cost
        val net = gross - r.lossTotal - r.expenseTotal
        val rows = ArrayList<DocRow>()

        rows += section("MONEY FROM SALES")
        rows += two("Sales (Revenue / Turnover)", s.sales, RowStyle.SUBTOTAL)

        rows += section("WHAT THE GOODS COST YOU")
        rows += two("What you paid for the items you sold (Cost of sales)", s.cost)
        rows += two("Profit on goods sold (Gross profit)", gross, RowStyle.SUBTOTAL)

        rows += section("STOCK LOSSES (damaged, expired, missing, own use)")
        if (r.losses.isEmpty()) rows += two("None recorded", 0.0)
        else r.losses.sortedByDescending { it.amount }.forEach { rows += two(it.name, it.amount) }
        rows += two("Total stock losses", r.lossTotal, RowStyle.SUBTOTAL)

        rows += section("RUNNING COSTS (Expenses)")
        if (r.expenses.isEmpty()) rows += two("None recorded", 0.0)
        else r.expenses.forEach { rows += two(it.name, it.amount) }
        rows += two("Total running costs", r.expenseTotal, RowStyle.SUBTOTAL)

        rows += two(
            if (net >= 0) "PROFIT for the period (Net profit)" else "LOSS for the period (Net loss)",
            net, RowStyle.TOTAL
        )
        if (s.sales > 0) {
            rows += note(
                "Out of every 100 you sold, you kept " + String.format("%.0f", net / s.sales * 100.0) +
                    " as profit after all costs."
            )
        }
        if (r.soldOnCredit > 0.005) {
            rows += note(
                "Includes " + m(r.soldOnCredit) + " sold on credit that customers may not have paid yet. " +
                    "See the Cash Flow statement for money actually received."
            )
        }
        return Doc(
            "pnl", "Profit and Loss Statement",
            "Shows whether the shop made a profit or a loss in this period.",
            rows, listOf(3.2f, 1.2f)
        )
    }

    // ------------------------------------------------------------------------------------------
    fun cashFlow(): Doc {
        val r = b.raw
        val rows = ArrayList<DocRow>()
        rows += two("Money in the shop at the start (cash + mobile money)", r.openingMoney, RowStyle.SUBTOTAL)

        rows += section("MONEY COMING IN")
        rows += two("Cash sales", r.method(Method.CASH))
        rows += two("Mobile money sales", r.method(Method.MOBILE))
        rows += two("Customers paying back what they owed", r.customerPaid)
        rows += two("Total money in", r.moneyIn, RowStyle.SUBTOTAL)

        rows += section("MONEY GOING OUT")
        rows += two("Stock bought and paid for", r.restockPaid)
        rows += two("Suppliers paid (stock bought earlier)", r.supplierPaid)
        rows += two("Running costs paid", r.expenseTotal)
        rows += two("Total money out", r.moneyOut, RowStyle.SUBTOTAL)

        rows += two("Money made (or lost) by running the shop", r.fromRunning, RowStyle.SUBTOTAL)

        rows += section("OWNER'S MONEY")
        rows += two("Money you put into the shop", r.ownerIn)
        rows += two("Money you took out for yourself", r.ownerOut)
        rows += two("Net owner's money", r.fromOwner, RowStyle.SUBTOTAL)

        rows += two("Money in the shop at the end (cash + mobile money)", r.closingMoney, RowStyle.TOTAL)

        rows += section("FOR YOUR INFORMATION")
        rows += two("Sold on credit this period (not received yet)", r.soldOnCredit)
        rows += two("Stock bought on credit this period (not paid yet)", (r.restockTotal - r.restockPaid))
        rows += note(
            "Cash Flow only counts money that really moved. A sale on credit is profit on the Profit " +
                "and Loss statement, but it is not money in your hand until the customer pays."
        )
        return Doc(
            "cashflow", "Cash Flow Statement",
            "Shows where your money came from and where it went.",
            rows, listOf(3.2f, 1.2f)
        )
    }

    // ------------------------------------------------------------------------------------------
    fun position(): Doc {
        val p = b.position
        val rows = ArrayList<DocRow>()
        rows += section("WHAT THE SHOP HAS")
        rows += two("Money (cash + mobile money)", p.money)
        rows += two("Stock on the shelves (at what you paid)", p.stockValue)
        rows += two("Customers who owe you", p.owedToShop)
        rows += two("Total the shop has", p.totalHas, RowStyle.SUBTOTAL)
        rows += section("WHAT THE SHOP OWES")
        rows += two("Suppliers you still have to pay", p.owedByShop)
        rows += two("Total the shop owes", p.owedByShop, RowStyle.SUBTOTAL)
        rows += two("WHAT THE SHOP IS WORTH NOW (Net worth)", p.netWorth, RowStyle.TOTAL)
        rows += note("This is a picture of the shop as of today (" + Fmt.date(System.currentTimeMillis()) + "), not of the selected period.")
        return Doc(
            "position", "What The Shop Has and Owes (Balance Sheet)",
            "A snapshot of everything the shop owns and owes today.",
            rows, listOf(3.2f, 1.2f)
        )
    }

    // ------------------------------------------------------------------------------------------
    fun salesByProduct(): Doc {
        val rows = ArrayList<DocRow>()
        rows += DocRow(listOf("Product", "Sold", "Sales", "Profit"), RowStyle.HEADER)
        val sorted = b.stats.sortedByDescending { it.revenue }
        for (p in sorted) rows += DocRow(listOf(p.name, Fmt.qty(p.qty), m(p.revenue), m(p.profit)))
        rows += DocRow(
            listOf("TOTAL", Fmt.qty(b.summary.units), m(b.summary.sales), m(b.summary.profit)),
            RowStyle.TOTAL
        )
        if (sorted.isEmpty()) rows += note("No sales recorded in this period.")
        return Doc(
            "products", "Sales by Product",
            "Which items sold the most and which made the most profit.",
            rows, listOf(2.6f, 0.8f, 1.2f, 1.2f)
        )
    }

    // ------------------------------------------------------------------------------------------
    fun salesOverTime(): Doc {
        val rows = ArrayList<DocRow>()
        val head = when (b.trendKind) {
            BucketKind.HOUR -> "Hour"
            BucketKind.DAY -> "Day"
            BucketKind.WEEK -> "Week starting"
            BucketKind.MONTH -> "Month"
        }
        rows += DocRow(listOf(head, "Sales", "Profit"), RowStyle.HEADER)
        for (t in b.trend) rows += DocRow(listOf(t.label, m(t.sales), m(t.profit)))
        rows += DocRow(listOf("TOTAL", m(b.summary.sales), m(b.summary.profit)), RowStyle.TOTAL)
        return Doc(
            "overtime", "Sales Over Time",
            "How sales and profit moved during the period.",
            rows, listOf(2.2f, 1.4f, 1.4f)
        )
    }

    // ------------------------------------------------------------------------------------------
    fun stockValuation(): Doc {
        val rows = ArrayList<DocRow>()
        rows += DocRow(listOf("Product", "In stock", "Cost each", "Stock value"), RowStyle.HEADER)
        var total = 0.0
        var shelfValue = 0.0
        for (p in b.products.sortedBy { it.name.lowercase() }) {
            val q = maxOf(0.0, p.stockQty)
            val v = q * p.costPrice
            total += v
            shelfValue += q * p.sellPrice
            rows += DocRow(listOf(p.name, Fmt.qty(p.stockQty), m(p.costPrice), m(v)))
        }
        rows += DocRow(listOf("TOTAL STOCK VALUE (at cost)", "", "", m(total)), RowStyle.TOTAL)
        rows += note(
            "If you sold all of this stock at today's prices you would receive " + m(shelfValue) +
                ", which is " + m(shelfValue - total) + " profit."
        )
        return Doc(
            "stock", "Stock Value (Inventory)",
            "What is on your shelves today and what it cost you.",
            rows, listOf(2.6f, 0.9f, 1.1f, 1.2f)
        )
    }

    // ------------------------------------------------------------------------------------------
    fun debts(): Doc {
        val p = b.position
        val rows = ArrayList<DocRow>()
        rows += section("CUSTOMERS WHO OWE YOU")
        if (p.debtors.isEmpty()) rows += note("Nobody owes you anything.")
        p.debtors.forEach { rows += two(it.name, it.amount) }
        rows += two("Total owed to you", p.owedToShop, RowStyle.SUBTOTAL)
        rows += section("SUPPLIERS YOU OWE")
        if (p.creditors.isEmpty()) rows += note("You do not owe any supplier.")
        p.creditors.forEach { rows += two(it.name, it.amount) }
        rows += two("Total you owe", p.owedByShop, RowStyle.SUBTOTAL)
        return Doc(
            "debts", "Who Owes Who",
            "Customers who still have to pay you, and suppliers you still have to pay.",
            rows, listOf(3.2f, 1.2f)
        )
    }
}
