package com.tuckshop.manager.domain

import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Offline licence keys. A key is tied to one phone: it is a signature (HMAC) of that phone's Device ID,
 * so the same key does not work on any other phone.
 */
object License {
    const val WHATSAPP = "263715048687"
    const val WHATSAPP_DISPLAY = "+263 715 048 687"
    const val TRIAL_MS = 24L * 60 * 60 * 1000

    // Must be identical to the secret inside keygen.html. Keep both private.
    private const val SECRET = "a0df32d6f84d4b6b615064145cd7ed5e"
    private const val ALPHABET = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"

    private fun base32(bytes: ByteArray, chars: Int): String {
        val sb = StringBuilder()
        var buf = 0
        var bits = 0
        var i = 0
        while (sb.length < chars) {
            if (bits < 5) {
                buf = (buf shl 8) or (bytes[i++].toInt() and 0xFF)
                bits += 8
            }
            bits -= 5
            sb.append(ALPHABET[(buf shr bits) and 31])
            buf = buf and ((1 shl bits) - 1)
        }
        return sb.toString()
    }

    private fun group(s: String): String = s.chunked(4).joinToString("-")

    fun normalize(s: String): String = s.uppercase().filter { it.isLetterOrDigit() }

    /** Short code shown on the lock screen, e.g. K7M2-9QXA. */
    fun deviceCode(androidId: String, packageName: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest((androidId + "|" + packageName).toByteArray(Charsets.UTF_8))
        return group(base32(d, 8))
    }

    fun keyFor(deviceCode: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(SECRET.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        val out = mac.doFinal(("TSM1|" + normalize(deviceCode)).toByteArray(Charsets.UTF_8))
        return group(base32(out, 16))
    }

    fun isValid(deviceCode: String, key: String): Boolean {
        val want = normalize(keyFor(deviceCode))
        val got = normalize(key)
        if (want.length != got.length) return false
        var diff = 0
        for (i in want.indices) diff = diff or (want[i].code xor got[i].code)
        return diff == 0
    }
}
