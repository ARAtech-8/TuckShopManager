package com.tuckshop.manager.io

import android.content.Context
import android.net.Uri
import com.tuckshop.manager.data.ShopDatabase
import java.io.File

/** Backup = a copy of the single database file. Restore = put a copy back. */
object Backup {
    fun export(context: Context, uri: Uri): Boolean = try {
        val src = context.getDatabasePath(ShopDatabase.NAME)
        context.contentResolver.openOutputStream(uri)?.use { out ->
            src.inputStream().use { it.copyTo(out) }
        } != null
    } catch (e: Exception) {
        false
    }

    /** Returns true if the file was a valid backup and has been put in place. The app must restart afterwards. */
    fun restore(context: Context, uri: Uri, db: ShopDatabase): Boolean = try {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        if (bytes == null || bytes.size < 16 || String(bytes, 0, 15, Charsets.US_ASCII) != "SQLite format 3") {
            false
        } else {
            db.close()
            val dest = context.getDatabasePath(ShopDatabase.NAME)
            dest.outputStream().use { it.write(bytes) }
            File(dest.path + "-wal").delete()
            File(dest.path + "-shm").delete()
            File(dest.path + "-journal").delete()
            true
        }
    } catch (e: Exception) {
        false
    }
}
