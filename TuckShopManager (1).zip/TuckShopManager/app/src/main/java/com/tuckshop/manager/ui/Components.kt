@file:OptIn(ExperimentalMaterial3Api::class)

package com.tuckshop.manager.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuckshop.manager.domain.Bucket
import com.tuckshop.manager.domain.Doc
import com.tuckshop.manager.domain.DocRow
import com.tuckshop.manager.domain.Fmt
import com.tuckshop.manager.domain.Period
import com.tuckshop.manager.domain.RowStyle
import kotlin.math.abs
import kotlin.math.max

val LocalSymbol = staticCompositionLocalOf { "$" }

/** Money with the shop's currency symbol, e.g. $12.50 or -$3.00. */
@Composable
fun money(v: Double): String {
    val s = LocalSymbol.current
    return (if (v < -0.004) "-" else "") + s + Fmt.money(abs(v))
}

fun profitColor(v: Double): Color = if (v < -0.004) Ui.Bad else Ui.Good

fun String.toNum(): Double? = trim().replace(',', '.').toDoubleOrNull()

/** "▲ 12% more than last week", or null if there is nothing to compare with. */
fun changeText(cur: Double, prev: Double, label: String): Pair<String, Color>? {
    if (abs(prev) < 0.005) return null
    val pct = (cur - prev) / abs(prev) * 100.0
    val up = pct >= 0
    val txt = (if (up) "▲ " else "▼ ") + String.format("%.0f", abs(pct)) + "% " + (if (up) "more " else "less ") + label
    return Pair(txt, if (up) Ui.Good else Ui.Bad)
}

// ---------------------------------------------------------------------------- frames
@Composable
fun ScreenFrame(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(title, fontWeight = FontWeight.Bold) },
            navigationIcon = {
                if (onBack != null) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                }
            },
            actions = actions,
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.primary,
                titleContentColor = Color.White,
                navigationIconContentColor = Color.White,
                actionIconContentColor = Color.White
            )
        )
        content()
    }
}

@Composable
fun SectionTitle(text: String, hint: String? = null) {
    Column(Modifier.padding(top = 8.dp, bottom = 4.dp)) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        if (hint != null) Text(hint, fontSize = 12.sp, color = Ui.Muted)
    }
}

@Composable
fun EmptyHint(text: String) {
    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Ui.Muted, textAlign = TextAlign.Center)
    }
}

@Composable
fun WhiteCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(14.dp), content = content)
    }
}

@Composable
fun StatCard(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: Color = Color.Unspecified,
    sub: String? = null,
    subColor: Color = Ui.Muted
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(label, fontSize = 12.sp, color = Ui.Muted)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub != null) Text(sub, fontSize = 11.sp, color = subColor)
        }
    }
}

// ---------------------------------------------------------------------------- inputs
@Composable
fun TextInput(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, hint: String? = null) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
        supportingText = if (hint != null) ({ Text(hint) }) else null,
        modifier = modifier.fillMaxWidth()
    )
}

private val numberPattern = Regex("^-?[0-9]*[.,]?[0-9]*$")

@Composable
fun NumInput(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, hint: String? = null) {
    OutlinedTextField(
        value = value,
        onValueChange = { v -> if (v.isEmpty() || numberPattern.matches(v)) onChange(v) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        supportingText = if (hint != null) ({ Text(hint) }) else null,
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun FormDialog(
    title: String,
    confirmText: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    confirmEnabled: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                content = content
            )
        },
        confirmButton = { Button(onClick = onConfirm, enabled = confirmEnabled) { Text(confirmText) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/** Ask for a single number (a quantity or a price). */
@Composable
fun NumberDialog(title: String, label: String, initial: Double, onDismiss: () -> Unit, onDone: (Double) -> Unit) {
    var text by remember { mutableStateOf(Fmt.qty(initial)) }
    val n = text.toNum()
    FormDialog(title, "OK", onDismiss, { if (n != null) onDone(n) }, confirmEnabled = n != null) {
        NumInput(text, { text = it }, label)
    }
}

@Composable
fun ChipChoice(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(options) { o ->
            FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(o) })
        }
    }
}

@Composable
fun PeriodChips(selected: Period, onSelect: (Period) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(Period.values().toList()) { p ->
            FilterChip(selected = p == selected, onClick = { onSelect(p) }, label = { Text(p.label) })
        }
    }
}

// ---------------------------------------------------------------------------- charts
@Composable
fun SalesChart(buckets: List<Bucket>, modifier: Modifier = Modifier) {
    val maxV = max(buckets.maxOfOrNull { it.sales } ?: 0.0, 0.01)
    val bar = Ui.Good
    val axis = Color(0xFFBBBBBB)
    Column(modifier) {
        Canvas(Modifier.fillMaxWidth().height(130.dp)) {
            val n = buckets.size
            if (n > 0) {
                val slot = size.width / n
                val barW = slot * 0.7f
                buckets.forEachIndexed { i, b ->
                    var h = (b.sales / maxV * size.height).toFloat()
                    if (b.sales > 0.0 && h < 3f) h = 3f
                    drawRect(
                        color = bar,
                        topLeft = Offset(i * slot + (slot - barW) / 2f, size.height - h),
                        size = Size(barW, h)
                    )
                }
                drawLine(axis, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = 2f)
            }
        }
        if (buckets.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(buckets.first().label, fontSize = 11.sp, color = Ui.Muted)
                if (buckets.size > 2) Text(buckets[buckets.size / 2].label, fontSize = 11.sp, color = Ui.Muted)
                Text(buckets.last().label, fontSize = 11.sp, color = Ui.Muted)
            }
        }
    }
}

data class RankItem(val name: String, val value: Double, val text: String)

@Composable
fun RankBars(items: List<RankItem>, color: Color) {
    val maxV = max(items.maxOfOrNull { abs(it.value) } ?: 0.0, 0.01)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { it ->
            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(it.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(it.text, fontWeight = FontWeight.Bold, color = if (it.value < 0) Ui.Bad else Color.Unspecified)
                }
                val frac = (abs(it.value) / maxV).toFloat().coerceIn(0.03f, 1f)
                Box(
                    Modifier.fillMaxWidth(frac).height(8.dp)
                        .background(if (it.value < 0) Ui.Bad else color, RoundedCornerShape(4.dp))
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------- statements
@Composable
fun DocRowView(row: DocRow, weights: List<Float>) {
    val bg = when (row.style) {
        RowStyle.SECTION -> Ui.Soft
        RowStyle.HEADER -> Color(0xFFEDEDED)
        RowStyle.TOTAL -> Color(0xFFD9EDE0)
        else -> Color.Transparent
    }
    if (row.style == RowStyle.NOTE) {
        Text(
            row.cells.firstOrNull() ?: "",
            Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
            fontSize = 12.sp, color = Ui.Muted, fontStyle = FontStyle.Italic
        )
        return
    }
    val bold = row.style != RowStyle.NORMAL
    Row(Modifier.fillMaxWidth().background(bg).padding(horizontal = 6.dp, vertical = 7.dp)) {
        row.cells.forEachIndexed { i, c ->
            val w = if (i < weights.size) weights[i] else 1f
            Text(
                c,
                Modifier.weight(w),
                textAlign = if (i == 0) TextAlign.Start else TextAlign.End,
                fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
                fontSize = if (row.style == RowStyle.TOTAL) 15.sp else 14.sp,
                color = when {
                    row.style == RowStyle.SECTION -> Ui.Good
                    i > 0 && c.startsWith("-") -> Ui.Bad
                    else -> Color.Unspecified
                }
            )
        }
    }
}

@Composable
fun DocView(doc: Doc, symbol: String) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(8.dp)) {
            Text("Amounts are in $symbol", fontSize = 11.sp, color = Ui.Muted, modifier = Modifier.padding(start = 6.dp, bottom = 4.dp))
            doc.rows.forEach { DocRowView(it, doc.weights) }
        }
    }
}

@Composable
fun ProvideSymbol(symbol: String, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalSymbol provides symbol, content = content)
}
