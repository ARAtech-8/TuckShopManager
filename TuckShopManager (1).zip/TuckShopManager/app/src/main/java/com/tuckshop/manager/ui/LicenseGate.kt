@file:OptIn(ExperimentalMaterial3Api::class)

package com.tuckshop.manager.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuckshop.manager.data.LicenseStore
import com.tuckshop.manager.domain.License
import kotlinx.coroutines.delay

/** Milliseconds left of the free trial, or null when the app is fully unlocked. */
val LocalTrialMsLeft = compositionLocalOf<Long?> { null }

fun trialText(ms: Long): String {
    val hours = ms / 3_600_000L
    return if (hours >= 1) "about $hours hour" + (if (hours == 1L) "" else "s") + " left" else "less than 1 hour left"
}

@Composable
fun LicenseGate(store: LicenseStore, content: @Composable () -> Unit) {
    var state by remember { mutableStateOf(store.state()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(20_000)
            state = store.state()
        }
    }
    if (state.locked) {
        LockScreen(store) { state = store.state() }
    } else {
        CompositionLocalProvider(LocalTrialMsLeft provides (if (state.activated) null else state.trialMsLeft)) {
            content()
        }
    }
}

@Composable
fun LockScreen(store: LicenseStore, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)
    ) {
        Text("Tuck Shop Manager", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ui.Good)
        Text("Your free trial has ended.", fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(
            "WhatsApp " + License.WHATSAPP_DISPLAY + " to get key",
            fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
        )
        Button(
            onClick = {
                val msg = "Hello, I would like a key for Tuck Shop Manager. My Device ID is " + store.deviceCode
                val uri = Uri.parse("https://wa.me/" + License.WHATSAPP + "?text=" + Uri.encode(msg))
                try {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (e: Exception) {
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Open WhatsApp") }

        WhiteCard {
            Text("Your Device ID (send this with your request)", fontSize = 12.sp, color = Ui.Muted)
            Text(store.deviceCode, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            OutlinedButton(
                onClick = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Device ID", store.deviceCode))
                },
                modifier = Modifier.padding(top = 6.dp)
            ) { Text("Copy Device ID") }
        }

        OutlinedTextField(
            value = key,
            onValueChange = { key = it; wrong = false },
            label = { Text("Type or paste your key") },
            singleLine = true,
            isError = wrong,
            supportingText = if (wrong) ({ Text("That key is not correct for this phone.") }) else null,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = {
                if (store.activate(key)) onChanged() else wrong = true
            },
            enabled = key.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Unlock") }

        Text(
            "Your records are safe. They will all be here when you unlock.",
            fontSize = 12.sp, color = Ui.Muted, textAlign = TextAlign.Center
        )
    }
}
