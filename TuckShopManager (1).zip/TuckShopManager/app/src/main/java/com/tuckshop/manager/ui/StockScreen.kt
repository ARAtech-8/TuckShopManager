@file:OptIn(ExperimentalMaterial3Api::class)

package com.tuckshop.manager.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuckshop.manager.ShopViewModel
import com.tuckshop.manager.data.Product
import com.tuckshop.manager.domain.Engine
import com.tuckshop.manager.domain.Fmt
import com.tuckshop.manager.domain.Period
import com.tuckshop.manager.domain.ReportBundle
import com.tuckshop.manager.io.ImportPreview
import com.tuckshop.manager.io.Importer
import com.tuckshop.manager.io.Share
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun StockScreen(vm: ShopViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val products by vm.products.collectAsState()
    val version by vm.repo.version.collectAsState()
    val bundle by produceState<ReportBundle?>(null, version) { value = vm.repo.bundle(Period.TODAY) }

    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("All") }
    var actionsFor by remember { mutableStateOf<Product?>(null) }
    var editing by remember { mutableStateOf<Product?>(null) }
    var adding by remember { mutableStateOf(false) }
    var restockFor by remember { mutableStateOf<Product?>(null) }
    var adjustFor by remember { mutableStateOf<Product?>(null) }
    var deleteFor by remember { mutableStateOf<Product?>(null) }
    var preview by remember { mutableStateOf<ImportPreview?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    try {
                        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        if (bytes == null) ImportPreview(emptyList(), 0, "Could not open that file.")
                        else Importer.toProducts(Importer.readTable(bytes))
                    } catch (e: Exception) {
                        ImportPreview(
                            emptyList(), 0,
                            "I could not read that file. Please save it as an Excel (.xlsx) or CSV file and try again."
                        )
                    }
                }
                preview = result
            }
        }
    }
    val templateSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(Importer.TEMPLATE_CSV.toByteArray()) }
                vm.say("Template saved. Open it in Excel, fill it in, then use Import.")
            } catch (e: Exception) {
                vm.say("Could not save the template.")
            }
        }
    }

    val lowIds = (bundle?.reorder ?: emptyList()).map { it.product.id }.toSet()
    val shown = products.filter { p ->
        (query.isBlank() || p.name.contains(query, true) || p.category.contains(query, true)) &&
            when (filter) {
                "Running low" -> p.id in lowIds && p.stockQty > 0
                "Out of stock" -> p.stockQty <= 0
                else -> true
            }
    }

    ScreenFrame("Stock", actions = {
        IconButton(onClick = {
            val list = bundle?.reorder ?: emptyList()
            if (list.isEmpty()) vm.say("Nothing is running low right now.")
            else {
                val text = "Shopping list - " + vm.settings.value.shopName + "\n" +
                    list.joinToString("\n") { "- " + it.product.name + ": buy about " + Fmt.qty(it.suggested) + " (have " + Fmt.qty(maxOf(0.0, it.product.stockQty)) + ")" }
                Share.shareText(ctx, text)
            }
        }) { Icon(Icons.Filled.Share, contentDescription = "Share shopping list", tint = Color.White) }
    }) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val value = Engine.stockValue(products)
            Text(
                products.size.toString() + " products   |   stock worth " + money(value) + " (what you paid)",
                color = Ui.Muted, fontSize = 13.sp
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { adding = true }, modifier = Modifier.weight(1f)) { Text("+ Add product") }
                FilledTonalButton(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) { Text("Import Excel") }
            }
            TextButton(onClick = { templateSaver.launch("product_list_template.csv") }) {
                Text("Get an Excel template to fill in")
            }
            OutlinedTextField(
                value = query, onValueChange = { query = it }, label = { Text("Search") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            ChipChoice(listOf("All", "Running low", "Out of stock"), filter) { filter = it }
        }
        if (products.isEmpty()) EmptyHint("No products yet.\nTap \"+ Add product\" or \"Import Excel\".")
        else if (shown.isEmpty()) EmptyHint("Nothing to show here.")
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(shown, key = { it.id }) { p -> StockRow(p, p.id in lowIds) { actionsFor = p } }
        }
    }

    // ------------------------------------------------------------ dialogs
    actionsFor?.let { p ->
        AlertDialog(
            onDismissRequest = { actionsFor = null },
            title = { Text(p.name, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("In stock: " + Fmt.qty(p.stockQty) + " " + p.unit + "\nBought at " + money(p.costPrice) + "   Sells for " + money(p.sellPrice))
                    Button(onClick = { restockFor = p; actionsFor = null }, modifier = Modifier.fillMaxWidth()) { Text("I bought more (add stock)") }
                    FilledTonalButton(onClick = { adjustFor = p; actionsFor = null }, modifier = Modifier.fillMaxWidth()) { Text("Remove stock (damaged, expired...)") }
                    OutlinedButton(onClick = { editing = p; actionsFor = null }, modifier = Modifier.fillMaxWidth()) { Text("Change name or prices") }
                    TextButton(onClick = { deleteFor = p; actionsFor = null }, modifier = Modifier.fillMaxWidth()) { Text("Delete this product", color = Ui.Bad) }
                }
            },
            confirmButton = { TextButton(onClick = { actionsFor = null }) { Text("Close") } }
        )
    }
    if (adding) ProductDialog(vm, null, products, onDismiss = { adding = false })
    editing?.let { ProductDialog(vm, it, products, onDismiss = { editing = null }) }
    restockFor?.let { RestockDialog(vm, it, onDismiss = { restockFor = null }) }
    adjustFor?.let { AdjustDialog(vm, it, onDismiss = { adjustFor = null }) }
    deleteFor?.let { p ->
        AlertDialog(
            onDismissRequest = { deleteFor = null },
            title = { Text("Delete " + p.name + "?") },
            text = { Text("It will disappear from your lists. Past sales stay in your reports.") },
            confirmButton = {
                Button(onClick = { vm.go("Deleted") { vm.repo.archiveProduct(p.id) }; deleteFor = null }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteFor = null }) { Text("Keep it") } }
        )
    }
    preview?.let { pv -> ImportPreviewDialog(vm, pv, products, onDismiss = { preview = null }) }
}

@Composable
private fun StockRow(p: Product, low: Boolean, onTap: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onTap),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(p.category + "  |  sells " + money(p.sellPrice), fontSize = 12.sp, color = Ui.Muted)
                if (p.sellPrice < p.costPrice) Text("Selling below cost!", fontSize = 12.sp, color = Ui.Bad)
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text(
                    Fmt.qty(p.stockQty), fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    color = if (p.stockQty <= 0) Ui.Bad else if (low) Ui.Warn else Color.Unspecified
                )
                Text(
                    if (p.stockQty <= 0) "out of stock" else if (low) "running low" else p.unit,
                    fontSize = 11.sp, color = if (p.stockQty <= 0) Ui.Bad else if (low) Ui.Warn else Ui.Muted
                )
            }
        }
    }
}

// ============================================================================ forms
@Composable
fun ProductDialog(vm: ShopViewModel, existing: Product?, all: List<Product>, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var category by remember { mutableStateOf(existing?.category ?: "") }
    var unit by remember { mutableStateOf(existing?.unit ?: "each") }
    var cost by remember { mutableStateOf(existing?.let { Fmt.qty(it.costPrice) } ?: "") }
    var sell by remember { mutableStateOf(existing?.let { Fmt.qty(it.sellPrice) } ?: "") }
    var qty by remember { mutableStateOf("") }
    var reorder by remember { mutableStateOf(existing?.let { Fmt.qty(it.reorderLevel) } ?: "5") }

    val c = cost.toNum() ?: 0.0
    val s = sell.toNum()
    val cats = all.map { it.category }.distinct().filter { it.isNotBlank() }.take(8)

    FormDialog(
        if (existing == null) "Add a product" else "Change product",
        "Save", onDismiss,
        onConfirm = {
            val p = (existing ?: Product(name = "")).copy(
                name = name.trim(),
                category = category.trim().ifBlank { "General" },
                unit = unit.trim().ifBlank { "each" },
                costPrice = c,
                sellPrice = s ?: 0.0,
                stockQty = if (existing == null) (qty.toNum() ?: 0.0) else existing.stockQty,
                reorderLevel = reorder.toNum() ?: 5.0
            )
            vm.go {
                if (vm.repo.productNameTaken(p.name, p.id)) vm.say("You already have a product called \"" + p.name + "\".")
                else {
                    vm.repo.saveProduct(p)
                    vm.say("Saved " + p.name)
                    onDismiss()
                }
            }
        },
        confirmEnabled = name.isNotBlank() && s != null
    ) {
        TextInput(name, { name = it }, "Product name (e.g. Coke 500ml)")
        TextInput(category, { category = it }, "Group (e.g. Drinks, Bread, Airtime)")
        if (cats.isNotEmpty()) ChipChoice(cats, category) { category = it }
        TextInput(unit, { unit = it }, "Sold by (each, kg, litre, packet...)")
        NumInput(cost, { cost = it }, "What you PAY for one", hint = "Leave empty if you don't know yet")
        NumInput(sell, { sell = it }, "What you SELL one for")
        if (s != null && s > 0) {
            val diff = s - c
            if (diff < 0) Text("You will LOSE " + money(-diff) + " on every one you sell!", color = Ui.Bad, fontWeight = FontWeight.Bold)
            else if (c > 0) Text("You make " + money(diff) + " on each (" + Fmt.pct(diff / s * 100.0) + " of the price).", color = Ui.Good)
        }
        if (existing == null) NumInput(qty, { qty = it }, "How many do you have right now?", hint = "Stock already on your shelf")
        NumInput(reorder, { reorder = it }, "Warn me when stock gets down to")
    }
}

@Composable
fun RestockDialog(vm: ShopViewModel, p: Product, onDismiss: () -> Unit) {
    var qty by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf(Fmt.qty(p.costPrice)) }
    var supplier by remember { mutableStateOf("") }
    var paidFull by remember { mutableStateOf(true) }
    var paidPart by remember { mutableStateOf("0") }

    val q = qty.toNum()
    val c = cost.toNum()
    val total = (q ?: 0.0) * (c ?: 0.0)
    val paid = if (paidFull) total else (paidPart.toNum() ?: 0.0)

    FormDialog(
        "Add stock: " + p.name, "Save", onDismiss,
        onConfirm = {
            vm.go("Stock added") { vm.repo.restock(p.id, q!!, c!!, supplier, minOf(paid, total)) }
            onDismiss()
        },
        confirmEnabled = q != null && q > 0 && c != null
    ) {
        Text("Now in stock: " + Fmt.qty(p.stockQty), color = Ui.Muted)
        NumInput(qty, { qty = it }, "How many did you buy?")
        NumInput(cost, { cost = it }, "Price you paid for one", hint = "We work out your average buying price for you")
        TextInput(supplier, { supplier = it }, "Who did you buy from? (optional)")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Paid in full?", Modifier.padding(top = 12.dp))
            Switch(checked = paidFull, onCheckedChange = { paidFull = it })
        }
        if (!paidFull) {
            NumInput(paidPart, { paidPart = it }, "How much did you pay now?")
            Text("You will still owe " + money(maxOf(0.0, total - paid)) + " to this supplier.", color = Ui.Warn)
        }
        Text("Total cost: " + money(total), fontWeight = FontWeight.Bold)
    }
}

@Composable
fun AdjustDialog(vm: ShopViewModel, p: Product, onDismiss: () -> Unit) {
    val reasons = listOf("Damaged", "Expired", "Missing or stolen", "Used at home", "Stock count fix")
    var reason by remember { mutableStateOf(reasons[0]) }
    var qty by remember { mutableStateOf("") }
    val isCount = reason == "Stock count fix"
    val n = qty.toNum()
    val change = if (n == null) null else if (isCount) n - p.stockQty else -n
    val lossValue = if (change == null) 0.0 else -change * p.costPrice

    FormDialog(
        "Remove stock: " + p.name, "Save", onDismiss,
        onConfirm = {
            vm.go("Stock updated") { vm.repo.adjust(p.id, change!!, reason) }
            onDismiss()
        },
        confirmEnabled = change != null && change != 0.0
    ) {
        Text("Now in stock: " + Fmt.qty(p.stockQty), color = Ui.Muted)
        ChipChoice(reasons, reason) { reason = it }
        NumInput(
            qty, { qty = it },
            if (isCount) "How many are on the shelf right now?" else "How many to remove?"
        )
        if (change != null && change != 0.0) {
            if (lossValue > 0) Text("This counts as a loss of " + money(lossValue) + " in your profit report.", color = Ui.Bad)
            else Text("Your stock goes up by " + Fmt.qty(change) + ".", color = Ui.Good)
        }
    }
}

@Composable
private fun ImportPreviewDialog(vm: ShopViewModel, pv: ImportPreview, existing: List<Product>, onDismiss: () -> Unit) {
    if (pv.error != null) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Could not import") },
            text = { Text(pv.error) },
            confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } }
        )
        return
    }
    val names = existing.map { it.name.lowercase() }.toSet()
    val updates = pv.rows.count { it.name.lowercase() in names }
    val news = pv.rows.size - updates
    val belowCost = pv.rows.count { it.sell != null && it.cost != null && it.sell < it.cost }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ready to import", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(pv.rows.size.toString() + " products found in the file.")
                Text("$news new, $updates already in your list.")
                if (updates > 0) Text(
                    "For the ones already in your list, prices (and stock numbers, if the file has them) will be replaced with the file's values.",
                    color = Ui.Warn, fontSize = 13.sp
                )
                if (pv.skipped > 0) Text(pv.skipped.toString() + " rows skipped (no name or a bad price).", color = Ui.Muted)
                if (belowCost > 0) Text("$belowCost products sell for less than they cost. Check these!", color = Ui.Bad)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    vm.go {
                        val r = vm.repo.importRows(pv.rows)
                        vm.say("Done: " + r.first + " added, " + r.second + " updated.")
                    }
                    onDismiss()
                },
                enabled = pv.rows.isNotEmpty()
            ) { Text("Import") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
